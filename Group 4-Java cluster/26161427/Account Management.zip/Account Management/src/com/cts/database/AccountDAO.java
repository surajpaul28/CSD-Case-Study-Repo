package com.cts.database;

import com.cts.model.Account;
import com.cts.exception.AccountNotFoundException;

import java.sql.*;

public class AccountDAO {
    private Connection connection;

    public AccountDAO(Connection connection) {
        this.connection = connection;
    }

    public int createAccount(Account account) throws SQLException {
        String sql = "INSERT INTO account (account_holder_name, balance) VALUES (?, ?)";
        PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        statement.setString(1, account.getAccountHolderName());
        statement.setDouble(2, account.getBalance());
        statement.executeUpdate();

        ResultSet generatedKeys = statement.getGeneratedKeys();
        if (generatedKeys.next()) {
            return generatedKeys.getInt(1);
        } else {
            throw new SQLException("Creating account failed, no ID obtained.");
        }
    }

    public Account getAccount(int accountId) throws SQLException, AccountNotFoundException {
        String sql = "SELECT * FROM account WHERE account_number = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, accountId);
        ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()) {
            Account account = new Account();
            account.setAccountNumber(resultSet.getInt("account_number"));
            account.setAccountHolderName(resultSet.getString("account_holder_name"));
            account.setBalance(resultSet.getDouble("balance"));
            return account;
        } else {
            throw new AccountNotFoundException("Account not found.");
        }
    }

    public void updateAccount(int accountId, String newName) throws SQLException {
        String sql = "UPDATE account SET account_holder_name = ? WHERE account_number = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, newName);
        statement.setInt(2, accountId);
        statement.executeUpdate();
    }

    public void closeAccount(int accountId) throws SQLException {
        String sql = "DELETE FROM account WHERE account_number = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, accountId);
        statement.executeUpdate();
    }

    public void depositFunds(int accountId, double amount) throws SQLException {
        String sql = "UPDATE account SET balance = balance + ? WHERE account_number = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setDouble(1, amount);
        statement.setInt(2, accountId);
        statement.executeUpdate();
    }

    public void withdrawFunds(int accountId, double amount) throws SQLException {
        String sql = "UPDATE account SET balance = balance - ? WHERE account_number = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setDouble(1, amount);
        statement.setInt(2, accountId);
        statement.executeUpdate();
    }

    public void transferFunds(int sourceAccountId, int targetAccountId, double amount) throws SQLException {
        connection.setAutoCommit(false);
        try {
            String withdrawSQL = "UPDATE account SET balance = balance - ? WHERE account_number = ?";
            PreparedStatement withdrawStatement = connection.prepareStatement(withdrawSQL);
            withdrawStatement.setDouble(1, amount);
            withdrawStatement.setInt(2, sourceAccountId);
            int rowsWithdrawn = withdrawStatement.executeUpdate();

            if (rowsWithdrawn > 0) {
                String depositSQL = "UPDATE account SET balance = balance + ? WHERE account_number = ?";
                PreparedStatement depositStatement = connection.prepareStatement(depositSQL);
                depositStatement.setDouble(1, amount);
                depositStatement.setInt(2, targetAccountId);
                int rowsDeposited = depositStatement.executeUpdate();

                if (rowsDeposited > 0) {
                    connection.commit();
                } else {
                    connection.rollback();
                    throw new SQLException("Target account not found. Transaction rolled back.");
                }
            } else {
                connection.rollback();
                throw new SQLException("Source account not found or insufficient funds. Transaction rolled back.");
            }
        } catch (SQLException e) {
            connection.rollback();
            throw e;
        } finally {
            connection.setAutoCommit(true);
        }
    }
}