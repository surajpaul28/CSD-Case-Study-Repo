package com.cts.database;

import com.cts.model.Transaction;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TransactionDAO {
    private Connection connection;

    public TransactionDAO(Connection connection) {
        this.connection = connection;
    }

    public void recordTransaction(int accountId, String transactionType, double amount) throws SQLException {
        String sql = "INSERT INTO transaction (account_number, transaction_type, amount) VALUES (?, ?, ?)";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, accountId);
        statement.setString(2, transactionType);
        statement.setDouble(3, amount);
        statement.executeUpdate();
    }

    public void showTransactionHistory(int accountId) throws SQLException {
        String sql = "SELECT * FROM transaction WHERE account_number = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, accountId);
        ResultSet resultSet = statement.executeQuery();

        System.out.println("+----------------+----------------+---------------------+--------------+----------------------+");
        System.out.println("| Transaction ID | Account Number | Transaction Type    | Amount       | Transaction Date     |");
        System.out.println("+----------------+----------------+---------------------+--------------+----------------------+");
        while (resultSet.next()) {
            System.out.printf("| %-14d | %-14d | %-19s | %-12.2f | %-20s |\n",
                    resultSet.getInt("transaction_id"),
                    resultSet.getInt("account_number"),
                    resultSet.getString("transaction_type"),
                    resultSet.getDouble("amount"),
                    resultSet.getTimestamp("transaction_date").toString());
        }
        System.out.println("+----------------+----------------+---------------------+--------------+----------------------+");
    }
}