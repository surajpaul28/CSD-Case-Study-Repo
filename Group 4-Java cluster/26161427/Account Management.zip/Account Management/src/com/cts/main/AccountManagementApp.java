package com.cts.main;

import com.cts.database.AccountDAO;
import com.cts.database.TransactionDAO;
import com.cts.database.DatabaseConnection;
import com.cts.model.Account;
import com.cts.exception.AccountNotFoundException;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class AccountManagementApp {

    public static void main(String[] args) {
        try {
            Connection connection = DatabaseConnection.getConnection();
            if (connection == null) {
                System.out.println("Failed to establish database connection. Exiting...");
                return;
            }

            AccountDAO accountDAO = new AccountDAO(connection);
            TransactionDAO transactionDAO = new TransactionDAO(connection);
            Scanner scanner = new Scanner(System.in);

            while (true) {
                System.out.println();
                System.out.println("=== Account Management ===");
                System.out.println("1. Create Account");
                System.out.println("2. View Account");
                System.out.println("3. Update Account");
                System.out.println("4. Close Account");
                System.out.println("5. Deposit Funds");
                System.out.println("6. Withdraw Funds");
                System.out.println("7. Transfer Funds");
                System.out.println("8. Show Transaction History");
                System.out.println("9. Exit");
                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        createAccount(accountDAO, scanner);
                        break;
                    case 2:
                        viewAccount(accountDAO, scanner);
                        break;
                    case 3:
                        updateAccount(accountDAO, scanner);
                        break;
                    case 4:
                        closeAccount(accountDAO, scanner);
                        break;
                    case 5:
                        depositFunds(accountDAO, transactionDAO, scanner);
                        break;
                    case 6:
                        withdrawFunds(accountDAO, transactionDAO, scanner);
                        break;
                    case 7:
                        transferFunds(accountDAO, transactionDAO, scanner);
                        break;
                    case 8:
                        showTransactionHistory(transactionDAO, scanner);
                        break;
                    case 9:
                        DatabaseConnection.closeConnection(connection);
                        exit();
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            }
        } catch (SQLException | InterruptedException | AccountNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void createAccount(AccountDAO accountDAO, Scanner scanner) throws SQLException {
        System.out.println("Enter Account holder name: ");
        String name = scanner.next();
        scanner.nextLine();
        System.out.println("Enter Initial Deposit: ");
        double balance = scanner.nextDouble();

        Account account = new Account();
        account.setAccountHolderName(name);
        account.setBalance(balance);

        int accountId = accountDAO.createAccount(account);
        System.out.println("Account created successfully! Account ID: " + accountId);
    }

    private static void viewAccount(AccountDAO accountDAO, Scanner scanner) throws SQLException, AccountNotFoundException {
        System.out.println("Enter Account ID to view: ");
        int accountId = scanner.nextInt();

        Account account = accountDAO.getAccount(accountId);
        System.out.println("+----------------+---------------------+--------------+");
        System.out.println("| Account ID     | Account Holder Name | Balance      |");
        System.out.println("+----------------+---------------------+--------------+");
        System.out.printf("| %-14d | %-19s | %-12.2f |\n",
                account.getAccountNumber(),
                account.getAccountHolderName(),
                account.getBalance());
        System.out.println("+----------------+---------------------+--------------+");
    }

    private static void updateAccount(AccountDAO accountDAO, Scanner scanner) throws SQLException {
        System.out.println("Enter Account ID to update: ");
        int accountId = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter new Account holder name: ");
        String newName = scanner.nextLine();

        accountDAO.updateAccount(accountId, newName);
        System.out.println("Account updated successfully!");
    }

    private static void closeAccount(AccountDAO accountDAO, Scanner scanner) throws SQLException {
        System.out.println("Enter Account ID to close: ");
        int accountId = scanner.nextInt();

        accountDAO.closeAccount(accountId);
        System.out.println("Account closed successfully!");
    }

    private static void depositFunds(AccountDAO accountDAO, TransactionDAO transactionDAO, Scanner scanner) throws SQLException {
        System.out.println("Enter Account ID to deposit to: ");
        int accountId = scanner.nextInt();
        System.out.println("Enter amount to deposit: ");
        double amount = scanner.nextDouble();

        accountDAO.depositFunds(accountId, amount);
        transactionDAO.recordTransaction(accountId, "Deposit", amount);
        System.out.println("Funds deposited successfully!");
    }

    private static void withdrawFunds(AccountDAO accountDAO, TransactionDAO transactionDAO, Scanner scanner) throws SQLException {
        System.out.println("Enter Account ID to withdraw from: ");
        int accountId = scanner.nextInt();
        System.out.println("Enter amount to withdraw: ");
        double amount = scanner.nextDouble();

        accountDAO.withdrawFunds(accountId, amount);
        transactionDAO.recordTransaction(accountId, "Withdrawal", amount);
        System.out.println("Funds withdrawn successfully!");
    }

    private static void transferFunds(AccountDAO accountDAO, TransactionDAO transactionDAO, Scanner scanner) throws SQLException {
        System.out.println("Enter source Account ID: ");
        int sourceAccountId = scanner.nextInt();
        System.out.println("Enter target Account ID: ");
        int targetAccountId = scanner.nextInt();
        System.out.println("Enter amount to transfer: ");
        double amount = scanner.nextDouble();

        accountDAO.transferFunds(sourceAccountId, targetAccountId, amount);
        transactionDAO.recordTransaction(sourceAccountId, "Transfer Out", amount);
        transactionDAO.recordTransaction(targetAccountId, "Transfer In", amount);
        System.out.println("Funds transferred successfully!");
    }

    private static void showTransactionHistory(TransactionDAO transactionDAO, Scanner scanner) throws SQLException {
        System.out.println("Enter Account ID to view transaction history: ");
        int accountId = scanner.nextInt();

        transactionDAO.showTransactionHistory(accountId);
    }

    private static void exit() throws InterruptedException {
        System.out.println("Exiting system");
        int i = 3;
        while (i > 0) {
            System.out.print(".");
            Thread.sleep(500);
            i--;
        }
        System.out.println();
        System.out.println("Thank you for using Account Management!!!");
    }
}